#! /usr/bin/env python
""" 
    Script for getting info of devices
    Copyright(c) 2020. PadronDenisse Baxter
"""
from datetime import datetime
from netmiko import ConnectHandler
from netmiko.ssh_exception import (
    AuthenticationException,
    NetMikoTimeoutException,
    SSHException,
)
import getpass
import csv
import xlrd
import sys

def get_info_ports (device):
    print ("########## Connecting to Device {0} ############".format(device['ip']))
    try:
        net_connect = ConnectHandler(**device)
        net_connect.enable()
        
        hname_cm = net_connect.send_command("sh run | in hostname")
        hnamelist = hname_cm.split()
        hostname = hnamelist[1]
        ports = net_connect.send_command("sh int status | in notconnect")
        int_ports = ports.splitlines()
        write_cvs(hostname,'Interface','Description','Used')
        #print (int_ports[1])
        i = 0
        for int in int_ports:
            try:
                int = int.split()
                interface = int [0]
                descrip = int[1]
                ports = net_connect.send_command(f"sh int {int[0]} | in Last input")
                port = ports.split()
                print (interface,descrip,ports)
                if ports:
                    #If never used
                    if 'never' in port[2] and 'never' in port[4]:
                        write_cvs(hostname,interface,descrip,'no')
                        continue
                   
                    #Hours since used
                    if ':' in ports:    
                        write_cvs(hostname,interface,descrip,'yes')
                        continue
                    #Days since used
                    if 'h' in port[2] or 'h' in port[4]:
                        write_cvs(hostname,interface,descrip,'yes')
                        continue
                    #Weeks since used
                    if 'w' in ports:
                        if 'w' in port[2]:
                            week = port[2]
                            w = convert_week(week[0])
                            if w > 5:
                                if 'w' in port [4]:
                                    week = port[2]
                                    w = convert_week(week[0])
                                    if w > 5:
                                        write_cvs(hostname,interface,descrip,'no')
                                        continue
                                    #If minor 
                                    else:
                                        write_cvs(hostname,interface,descrip,'yes')
                                        continue
                                #If w in second port
                                else:
                                    write_cvs(hostname,interface,descrip,'no')
                                    continue
                            #If minor of 5
                            else:
                                write_cvs(hostname,interface,descrip,'yes')
                                continue
                        #If w in firts port
                        else:
                            if 'w' in port [4]:
                                week = port[2]
                                w = convert_week(week[0])
                                if w > 5:
                                    write_cvs(hostname,interface,descrip,'no')
                                    continue
                                else:
                                    write_cvs(hostname,interface,descrip,'yes')
                                    continue
                    #Years since used
                    if 'y' in port[2] or 'y' in port[4]:
                        write_cvs(hostname,interface,descrip,'no')
                        continue
                #If ports
                else:
                    write_cvs(hostname,interface,descrip,'yes')
                    continue
                    
            except:
                continue
        
        net_connect.disconnect()
    
          
    except (AuthenticationException):
        label2 = "\n##### Authentication failure: " + device["ip"] + " #####\n"
        print(label2)
    except (NetMikoTimeoutException):
        label2 = "\n##### Time out to device: " + device["ip"] + " #####\n"
        print(label2)
    except (EOFError):
        label3 = (
            "\n##### End of file while attempting device: " + device["ip"] + " #####\n"
        )
        print(label3)
    except (SSHException):
        label4 = (
            "\n##### SSH issue. Check if SSHv2 is enabled: " + device["ip"] + " #####\n"
        )
        print(label4)
    
def convert_week (week):
    week = int(week)
    return week

   
def write_cvs(hostname,interface,description,status):
    with open(f"PuertosDisponibles_{hostname}.csv", "a", newline='') as csvfile:
        fieldnames = ['Interface','Description','Used']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        print (f"**************** Getting info from:  {interface} ********************")
        writer.writerow({'Interface': interface, 
                         'Description': description, 
                         'Used': status})
    csvfile.close()
    print (f"'''''''''''''''''''' Success  {interface} '''''''''''''''''''''")
       
               
def device_dict(ipaddr,myusername,mypass):
    device = {
        "device_type": "cisco_ios",
        "ip": ipaddr,
        "username": myusername,
        "password": mypass,
        "secret": mypass,
    }
    get_info_ports(device)   

def main ():
    myusername = input("Enter your username: ")
    mypass = getpass.getpass()
    ipaddr = input("Enter the IP Address: ")
    bgp = []
    desc = []
    threads = []
    start_info = True
    device = device_dict(ipaddr,myusername,mypass)

if __name__ == "__main__":
    main()
