#! /usr/bin/env python
""" 
    Script for getting info of devices
    Copyright(c) 2020. PadronDenisse Baxter
"""
from datetime import datetime
from netmiko import ConnectHandler
from netmiko.ssh_exception import (
    AuthenticationException,
    NetMikoTimeoutException,
    SSHException,
)
from threading import Thread
import getpass
import csv
import xlrd
import sys

def get_info_ports (device,ipaddr,hostname):
    print (f"########## Connecting to Device {ipaddr} ############")
    try:
        net_connect = ConnectHandler(**device)
        net_connect.enable()
        
        ports = net_connect.send_command("sh int status | in notconnect")
        int_ports = ports.splitlines()
        write_cvs(hostname,'Interface','Description','Used')
        #print (int_ports[1])
        print (f"########## Connecting to Hostname {hostname} ############")
        i = 0
        threads = []
        for int in int_ports:
            t = Thread(target=clasify_time, args=(device,ipaddr,hostname,int))
            t.start()
            threads.append(t)
        
        for t in threads:
            t.join()
        
        net_connect.disconnect()
    
          
    except (AuthenticationException):
        label2 = "\n##### Authentication failure: " + device["ip"] + " #####\n"
        print(label2)
    except (NetMikoTimeoutException):
        label2 = "\n##### Time out to device: " + device["ip"] + " #####\n"
        print(label2)
    except (EOFError):
        label3 = (
            "\n##### End of file while attempting device: " + device["ip"] + " #####\n"
        )
        print(label3)
    except (SSHException):
        label4 = (
            "\n##### SSH issue. Check if SSHv2 is enabled: " + device["ip"] + " #####\n"
        )
        print(label4)
    
def clasify_time (device,ipaddr,hostname,int):
    net_connect = ConnectHandler(**device)
    net_connect.enable()
    try:
        int = int.split()
        interface = int [0]
        description = net_connect.send_command(f"sh int description | in {int[0]}")
        descrip = description.splitlines()
        descrip = descrip[0].split()
        leng = len(descrip)
        print (leng)
        if leng > 2:
            des = descrip[3:leng]
            descrip = des
        else:
            des = ' '
            descrip = des
            ports = net_connect.send_command(f"sh int {int[0]} | in Last input")
            port = ports.split()
        print (interface,descrip,ports)
        if ports:
            #If never used
            if 'never' in port[2] and 'never' in port[4]:
                write_cvs(hostname,interface,descrip,'no')
                #continue
                 
            #Hours since used
            if ':' in ports:    
                write_cvs(hostname,interface,descrip,'yes')
                #continue
            #Days since used
            if 'h' in port[2] or 'h' in port[4]:
                write_cvs(hostname,interface,descrip,'yes')
                #continue
            #Weeks since used
            if 'w' in ports:
                if 'w' in port[2]:
                    week = port[2]
                    index = week.find('w')
                    print (index)
                    w = convert_week(week[0:index])
                    if w > 5:
                        if 'w' in port [4]:
                            week = port[4]
                            index = week.find('w')
                            w = convert_week(week[0:index])
                            if w > 5:
                                write_cvs(hostname,interface,descrip,'no')
                                #continue
                            #If minor 
                            else:
                                write_cvs(hostname,interface,descrip,'yes')
                                #continue
                        #If w in second port
                        else:
                            write_cvs(hostname,interface,descrip,'no')
                            #continue
                    #If minor of 5
                    else:
                        write_cvs(hostname,interface,descrip,'yes')
                        #continue
                #If w in firts port
                else:
                    if 'w' in port [4]:
                        week = port[4]
                        index = week.find('w')
                        w = convert_week(week[0:index])
                        if w > 5:
                            write_cvs(hostname,interface,descrip,'no')
                            #continue
                        else:
                            write_cvs(hostname,interface,descrip,'yes')
                            #continue
                    else:
                        write_cvs(hostname,interface,descrip,'yes')
                        #continue
            #Years since used
            if 'y' in port[2] or 'y' in port[4]:
                write_cvs(hostname,interface,descrip,'no')
                #continue
        #If ports
        else:
            write_cvs(hostname,interface,descrip,'yes')
            #continue
                
    except:
        write_cvs(hostname,interface,descrip,' ')
        #continue
        
    net_connect.disconnect()
    

def convert_week (week):
    week = int(week)
    print (f"In here is {week} weekkkkkkkkkkkkkkk")
    return week

   
def write_cvs(hostname,interface,description,status):
    with open(f"PuertosDisponibles_{hostname}.csv", "a", newline='') as csvfile:
        fieldnames = ['Interface','Description','Used']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        print (f"**************** Getting info from:  {interface} ********************")
        writer.writerow({'Interface': interface, 
                         'Description': description, 
                         'Used': status})
    csvfile.close()
    print (f"'''''''''''''''''''' Success  {interface} '''''''''''''''''''''")
       
               
def device_dict(ipaddr,myusername,mypass,hostname):
    device = {
        "device_type": "cisco_ios",
        "ip": ipaddr,
        "username": myusername,
        "password": mypass,
        "secret": mypass,
    }
    get_info_ports(device,ipaddr,hostname)   

def main ():
    myusername = 'padrond'
    mypass = 'Dennyplz25'
    #myusername = input("Enter your username: ")
    #mypass = getpass.getpass()
    #ipaddr = input("Enter the IP Address: ")
    
    workbook = xlrd.open_workbook(r"AccessSwitchesDeerfield.xls")
    sheet = workbook.sheet_by_index(0)
    threads = []
    for index in range(1, sheet.nrows):
        hostname = sheet.row(index)[0].value
        ipaddr = sheet.row(index)[1].value
        device_dict(ipaddr,myusername, mypass,hostname)
        #t.start()
        #threads.append(t)
        
    #for t in threads:
        #t.join()

if __name__ == "__main__":
    main()
