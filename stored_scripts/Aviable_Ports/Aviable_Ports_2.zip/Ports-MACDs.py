#! /usr/bin/env python
""" 
    Script for getting info of devices
    Copyright(c) 2020. PadronDenisse Baxter
"""
from datetime import datetime
from netmiko import ConnectHandler
from netmiko.ssh_exception import (
    AuthenticationException,
    NetMikoTimeoutException,
    SSHException,
)
import getpass
import csv
import xlrd
import sys
import requests

def get_info_ports (device,ipaddr):
    print (f"########## Connecting to Device {ipaddr} ############")
    try:
        net_connect = ConnectHandler(**device)
        net_connect.enable()
        
        hname_cm = net_connect.send_command("sh run | in hostname")
        hnamelist = hname_cm.split()
        hostname = hnamelist[1]
        ports = net_connect.send_command("sh int status")
        int_ports = ports.splitlines()
        write_cvs(hostname,'Interface','Description','Status','Vlan','Duplex','Speed','Type','Used','MACD','Vendor')
        print (int_ports[1])
        """
        int_MACD = net_connect.send_command("sh mac address-table")
        int_MACDs = int_MACD.splitlines()
        for MACDs in int_MACDs:
            if '/' in MACDs:
                inter_macd.append(MACDs)                
            else:
                continue
            #print (details)
        print (inter_macd)
        """
        print (f"########## Connecting to Hostname {hostname} ############")
        i = 0
        for int in int_ports:
            try:
                intp = int.split()
                interface = intp[0]
                #print(intp)
                #Posicion connected/notconnected
                try:
                    p_status = intp.index('connected')
                    status = 'connected'
                except:
                    p_status = intp.index('notconnect')
                    status = 'notconnected'
                #print(status)
                
                stat = intp[p_status]
                vlan = intp[p_status+1]
                duplex = intp[p_status+2]
                speed = intp[p_status+3]
                leng_1 = p_status+4
                type_p = intp[leng_1:len(intp)]
                
                #print (vlan,duplex,speed,type_p)
                
                int_MACD = net_connect.send_command(f"sh mac address-table | in {intp[0]}")
                try:
                    int_macd = int_MACD.split()
                    if '/' in int_macd[3]:
                        MACD = int_macd[1]
                        Vendor = MACDs_API(MACD)
                    else:
                        MACD = ' ' 
                        Vendor = ' '
                except:
                    MACD = ' ' 
                    Vendor = ' '
                    
                
                description = net_connect.send_command (f"sh int {intp[0]} descrip")
                descri = description.split()
                descrip= descri[7:len(descri)]
                descrip = convert(descrip)
                ports = net_connect.send_command(f"sh int {intp[0]} | in Last input")
                port = ports.split()
                print (interface,descrip,ports)
                
                if status is 'connected':
                    write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'yes',MACD,Vendor)
                    continue
                
                if ports:
                    #If never used
                    if 'never' in port[2] and 'never' in port[4]:
                        write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'no',MACD,Vendor)
                        continue
                       
                    #Hours since used
                    if ':' in ports:    
                        write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'yes',MACD,Vendor)
                        continue
                    #Days since used
                    if 'h' in port[2] or 'h' in port[4]:
                        write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'yes',MACD,Vendor)
                        continue
                    #Weeks since used
                    if 'w' in ports:
                        if 'w' in port[2]:
                            week = port[2]
                            index = week.find('w')
                            print (index)
                            w = convert_week(week[0:index])
                            if w > 11:
                                if 'w' in port [4]:
                                    week = port[4]
                                    index = week.find('w')
                                    w = convert_week(week[0:index])
                                    if w > 11:
                                        if 'y' in port[2] or 'y' in port[4]:
                                            write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'no',MACD,Vendor)
                                            continue
                                        else:
                                            write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'no',MACD,Vendor)
                                            continue
                                    #If minor 
                                    else:
                                        write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'yes',MACD,Vendor)
                                        continue
                                #If w in second port
                                else:
                                    write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'no',MACD,Vendor)
                                    continue
                            #If minor of 5
                            else:
                                write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'yes',MACD,Vendor)
                                continue
                        #If w in firts port
                        else:
                            if 'w' in port [4]:
                                week = port[4]
                                index = week.find('w')
                                w = convert_week(week[0:index])
                                if w > 11:
                                    if 'y' in port[2] or 'y' in port[4]:
                                        write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'no',MACD,Vendor)
                                        continue
                                    else:    
                                        write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'no',MACD,Vendor)
                                        continue
                                else:
                                    write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'yes',MACD,Vendor)
                                    continue
                            else:
                                write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'yes',MACD,Vendor)
                                continue
                
                #If ports
                
                else:
                    print ('jeje')
                    write_cvs(hostname,interface,descrip,stat,vlan,duplex,speed,type_p,'yes',MACD,Vendor)
                    continue       
                     
            except:
                continue    
        net_connect.disconnect()
    
          
    except (AuthenticationException):
        label2 = "\n##### Authentication failure: " + device["ip"] + " #####\n"
        print(label2)
    except (NetMikoTimeoutException):
        label2 = "\n##### Time out to device: " + device["ip"] + " #####\n"
        print(label2)
    except (EOFError):
        label3 = (
            "\n##### End of file while attempting device: " + device["ip"] + " #####\n"
        )
        print(label3)
    except (SSHException):
        label4 = (
            "\n##### SSH issue. Check if SSHv2 is enabled: " + device["ip"] + " #####\n"
        )
        print(label4)

def MACDs_API (MACD):
    try:
        MAC_URL = 'http://macvendors.co/api/%s'
        r = requests.get(MAC_URL % MACD)
        y = r.json()
        company = y['result']['company']
    except:
        company = 'Vendor not found'
    #print (MACD,interface_MAC,company)   
    return company 

def convert_week (week):
    week = int(week)
    print (f"In here is {week} weekkkkkkkkkkkkkkk")
    return week

def convert(s): 
    str1 = "" 
    return(str1.join(s)) 
   
def write_cvs(hostname,interface,description,stat,vlan,duplex,speed,type_p,used,macd,vendor):
    with open(f"PuertosDisponibles_{hostname}.csv", "a", newline='') as csvfile:
        fieldnames = ['Interface','Description','Status','Vlan','Duplex','Speed','Type','Used','MACD','Vendor']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        print (f"**************** Getting info from:  {interface} ********************")
        writer.writerow({'Interface': interface, 
                         'Description': description,
                         'Status': stat, 
                         'Vlan': vlan, 
                         'Duplex': duplex, 
                         'Speed': speed, 
                         'Type': type_p, 
                         'Used': used,
                         'MACD': macd,
                         'Vendor': vendor})
    csvfile.close()
    print (f"'''''''''''''''''''' Success  {interface} '''''''''''''''''''''")
       
               
def device_dict(ipaddr,myusername,mypass):
    device = {
        "device_type": "cisco_ios",
        "ip": ipaddr,
        "username": myusername,
        "password": mypass,
        "secret": mypass,
    }
    get_info_ports(device,ipaddr)   

def main ():
    #myusername = input("Enter your username: ")
    #mypass = getpass.getpass()
    ipaddr = input("Enter the IP Address: ")
    myusername= 'padrond'
    mypass = 'Dennyplz25'
    
    device_dict(ipaddr,myusername,mypass)
      

if __name__ == "__main__":
    main()
